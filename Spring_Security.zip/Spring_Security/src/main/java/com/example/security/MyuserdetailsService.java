package com.example.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class MyuserdetailsService implements UserDetailsService {
	
	
	
	@Autowired
	private UserRespository repo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		User USer=repo.findByUsername(username);
		if(USer==null)
			throw new UsernameNotFoundException("user 4040 found");
		
		return new UserPrincipal(USer);
	}

}
