package com.example.demo;





import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.model.Alien;

@Controller
public class HomeController1 {
	
	
	@Autowired  
	  AlienRepo repo;
	
	
	
	    @RequestMapping("/")    // @GetMapping,PostMapping
		public String home()
		{
	    	
		  return "index";
			
		}
	    
//	    @RequestMapping("add")
//	    public String add(HttpServletRequest req)       // general method of using values form jsp page
//	    
//	    {
//	    	int i=Integer.parseInt(req.getParameter("num1"));
//	    	int j=Integer.parseInt(req.getParameter("num2"));
//	    	
//	    	int R= i + j;  
//	    	
//	    	HttpSession session=req.getSession();
//	    	session.setAttribute("added", R);
//	    	
//	    	return  "result.jsp";
//	    }
	
//	    @RequestMapping("add")     // using annotations using values from jsp page
//	    public String add(@RequestParam("num1") int i,@RequestParam("num2") int j,HttpSession session)
//	    
//	    {
//	    	
//	    	int R= i + j;
//	    	session.setAttribute("added", R);
//	    	return  "result.jsp";
//	    }
	    
//	    @RequestMapping("add")     
//	    public ModelAndView add(@RequestParam("num1") int i,@RequestParam("num2") int j)
//	    
//	    {
//	    	ModelAndView mv=new ModelAndView();
//	    	mv.setViewName("result.jsp");
//	    	
//	    	int R= i + j;
//	    	
//	    	
//	    	mv.addObject("added",R);
//	    	
//	    	return  mv;
//	    }

	    
//	    @RequestMapping("add")       //  without using .jsp extension  and configuring in application prefix and suffix 
//	    public ModelAndView add(@RequestParam("num1") int i,@RequestParam("num2") int j)
//	    
//	    {
//	    	ModelAndView mv=new ModelAndView();   //  Model , ModelMap can be used
//	    	mv.setViewName("result");
//	    	
//	    	int R= i + j;
//	    	
//	    	
//	    	mv.addObject("added",R);
//	    	
//	    	return  mv;
//	    }

	    
	
//	    @RequestMapping("addAlien")            // using object  ......and storing in result page
//	    public String addAlien(@RequestParam("aid") int aid,@RequestParam("aname") String aname,Model m)
//	    {
//	   
//	    	Alien a =new Alien();
//	    	a.setAid(aid);
//	    	a.setAname(aname);
//	    	m.addAttribute("alien",a);
//	    	
//			return "result";
//	    	   
//	    }
	    

	    @RequestMapping("addAlien")           // @ModelAttribute  for parameter level
	    public String addAlien(@ModelAttribute("a1") Alien a)
	    {
	    	
	    
			return "result";
	    	   
	    } 
	    
	    
	  @ModelAttribute                        // ModelAttribute at Model level
	  public void Modeldata(Model m)
	  {
		  m.addAttribute("name","Aliens");
	  }
	    
	    
//	   @GetMapping("getAliens")
//	   public String getAliens(Model a)
//	   
//	   {
//		   
//		   List<Alien> aliens =Arrays.asList(new Alien(101,"navin"),new Alien(102,"rose"));
//		   a.addAttribute("result",aliens);
//		   
//		   
//		return "showAliens";
//		   
//	   }
	    
	    
	    
	  @GetMapping("getAliens")
	   public String getAliens(Model a)
	   
	   {
		   
		  
		a.addAttribute("result",repo.findAll());
		   
		   
		return "showAliens";
		   
	   }   
	    
	   
	    
	   
		  @GetMapping("getAlien")
		   public String getAliens(@RequestParam int aid, Model m)
		   
		   {
			   
			  
			m.addAttribute("result",repo.getOne(aid));
			   
			   
			return "showAliens";
		   }   
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
}
 